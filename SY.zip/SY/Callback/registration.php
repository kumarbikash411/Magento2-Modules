<?php
/**
 * Callback
 * 
 * @author Slava Yurthev
 */
\Magento\Framework\Component\ComponentRegistrar::register(
	\Magento\Framework\Component\ComponentRegistrar::MODULE,
	'SY_Callback',
	__DIR__
);